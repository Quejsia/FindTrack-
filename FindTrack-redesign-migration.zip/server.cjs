var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_vite = require("vite");
var import_genai = require("@google/genai");
var import_dotenv = __toESM(require("dotenv"), 1);
var import_express_rate_limit = __toESM(require("express-rate-limit"), 1);
var import_app = require("firebase-admin/app");
var import_auth = require("firebase-admin/auth");
if (!(0, import_app.getApps)().length) {
  (0, import_app.initializeApp)();
}
import_dotenv.default.config();
var app = (0, import_express.default)();
var PORT = 3e3;
app.use(import_express.default.json({ limit: "12mb" }));
app.use(import_express.default.urlencoded({ limit: "12mb", extended: true }));
var apiLimiter = (0, import_express_rate_limit.default)({
  windowMs: 15 * 60 * 1e3,
  // 15 minutes
  max: 20,
  // max 20 requests per 15 minutes per IP
  message: { error: "Too many requests from this IP, please try again after 15 minutes." }
});
var requireAuth = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    res.status(401).json({ error: "Unauthorized: Missing or invalid token." });
    return;
  }
  const token = authHeader.split("Bearer ")[1];
  try {
    const decodedToken = await (0, import_auth.getAuth)().verifyIdToken(token);
    req.user = decodedToken;
    next();
  } catch (error) {
    res.status(401).json({ error: "Unauthorized: Invalid token." });
  }
};
var aiClient = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined in system secrets.");
    }
    aiClient = new import_genai.GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build"
        }
      }
    });
  }
  return aiClient;
}
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
});
app.post("/api/analyze-image", apiLimiter, requireAuth, async (req, res) => {
  try {
    const { imageBase64, mimeType } = req.body;
    if (!imageBase64 || !mimeType) {
      res.status(400).json({ error: "imageBase64 and mimeType fields are required." });
      return;
    }
    const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
    if (!ALLOWED_TYPES.includes(mimeType)) {
      res.status(400).json({ error: "Invalid image type." });
      return;
    }
    const ai = getGeminiClient();
    const imagePart = {
      inlineData: {
        mimeType,
        data: imageBase64
      }
    };
    const promptString = `Analyze this image of a lost or found item. Extract details to auto-classify it for a Lost & Found tracker app.
Return a structured representation containing:
1. a clean, descriptive title (e.g., "Silver Metal Keychain" or "Red Leather iPhone Case").
2. category (must be one of: "electronics", "keys", "wallet", "documents", "clothing", "jewelry", "bags", "others").
3. a detailed physical description listing colors, distinguishing marks, brand labels, textures, shapes.
4. suggestedLocation (where such an item is commonly lost or found based on visual clues, or default to general guess).`;
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: { parts: [imagePart, { text: promptString }] },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          properties: {
            title: { type: import_genai.Type.STRING, description: "Descriptive title for the item (3-8 words)" },
            category: {
              type: import_genai.Type.STRING,
              description: "Primary category fits the item",
              enum: ["electronics", "keys", "wallet", "documents", "clothing", "jewelry", "bags", "others"]
            },
            description: { type: import_genai.Type.STRING, description: "Exhaustive physical attributes and identifying details" },
            suggestedLocation: { type: import_genai.Type.STRING, description: "Inferred location clue from image background if any" }
          },
          required: ["title", "category", "description", "suggestedLocation"]
        }
      }
    });
    const outputText = response.text;
    if (!outputText) {
      throw new Error("Gemini API did not return text response.");
    }
    const parsed = JSON.parse(outputText.trim());
    res.json(parsed);
  } catch (error) {
    console.error("Error analyzing image:", error);
    res.status(500).json({
      error: "Failed to analyze item image using AI engine.",
      details: error instanceof Error ? error.message : String(error)
    });
  }
});
app.post("/api/ai-matchmaker", apiLimiter, requireAuth, async (req, res) => {
  try {
    const { itemToMatch, candidates } = req.body;
    if (!itemToMatch || !candidates || !Array.isArray(candidates)) {
      res.status(400).json({ error: "itemToMatch and candidates array are required." });
      return;
    }
    if (candidates.length === 0) {
      res.json({ matches: [] });
      return;
    }
    const ai = getGeminiClient();
    const instructionsPrompt = `You are the core intelligence matching engine for the Lost & Found app, FindTrack.
We have a target item that was ${itemToMatch.type === "lost" ? "LOST" : "FOUND"}:
- Title: ${JSON.stringify(itemToMatch.title)}
- Category: ${JSON.stringify(itemToMatch.category)}
- Description: ${JSON.stringify(itemToMatch.description)}
- Location Tracked: ${JSON.stringify(itemToMatch.location)}
- Date Posted: ${JSON.stringify(itemToMatch.date)}

Compare this target item against the following candidates of the opposite tracking list:
${JSON.stringify(candidates.map((c) => ({ id: c.id, title: c.title, category: c.category, description: c.description, location: c.location, date: c.date })))}

For each candidate, calculate:
1. A confidence score between 0 and 100 based on overlap of physical characteristics, colors, brands, categories (critical!), and logical distance of locations and dates.
2. A matchReason: a friendly explanation (max 2 sentences) describing why they are a likely match, comparing matching features.

Filter and return ONLY matches having a confidence score of 35% or higher. Sort the results with higher confidence scores of matching first.`;
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: instructionsPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          properties: {
            matches: {
              type: import_genai.Type.ARRAY,
              items: {
                type: import_genai.Type.OBJECT,
                properties: {
                  itemId: { type: import_genai.Type.STRING, description: "The unique candidate ID" },
                  confidenceScore: { type: import_genai.Type.INTEGER, description: "Percentage probability of match (0-100)" },
                  matchReason: { type: import_genai.Type.STRING, description: "Justification for the confidence index" }
                },
                required: ["itemId", "confidenceScore", "matchReason"]
              }
            }
          },
          required: ["matches"]
        }
      }
    });
    const outputText = response.text;
    if (!outputText) {
      throw new Error("Gemini API did not return comparison parameters.");
    }
    const parsed = JSON.parse(outputText.trim());
    res.json(parsed);
  } catch (error) {
    console.error("Error in AI matchmaker:", error);
    res.status(500).json({
      error: "Match reasoning failed.",
      details: error instanceof Error ? error.message : String(error)
    });
  }
});
app.post("/api/verify-claim", apiLimiter, requireAuth, async (req, res) => {
  try {
    const { claimerAnswer, secretAnswer, securityQuestion } = req.body;
    if (!claimerAnswer || !secretAnswer) {
      res.status(400).json({ error: "Missing required fields." });
      return;
    }
    const ai = getGeminiClient();
    const promptString = `You are a verification engine for a Lost and Found system. 
The owner has set a secret question (optional) and a secret answer for their item.
A claimant is trying to claim the item. Your job is to verify if their answer is correct.

Owner's Secret Question: ${securityQuestion || "N/A"}
Owner's Expected Answer: ${secretAnswer}
Claimant's Answer: ${claimerAnswer}

INSTRUCTIONS:
1. Determine if the Claimant's Answer reasonably matches the Owner's Expected Answer logically or factually.
2. Account for typos, phrasing differences, or synonymous interpretations.
3. If the claimant's answer is complete gibberish, clearly random words, or an obvious prank, or if it radically contradicts the expected answer, REJECT it.
4. If it's a plausible match, ACCEPT it.

Return ONLY a raw JSON object matching the following schema.`;
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: [{ role: "user", parts: [{ text: promptString }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: import_genai.Type.OBJECT,
          properties: {
            match: { type: import_genai.Type.BOOLEAN, description: "True if it reasonably matches, false otherwise" },
            reason: { type: import_genai.Type.STRING, description: "Brief explanation why it was accepted or rejected (max 1 sentence)" }
          },
          required: ["match", "reason"]
        }
      }
    });
    const outputText = response.text;
    if (!outputText) {
      throw new Error("No output from Gemini");
    }
    const parsed = JSON.parse(outputText.trim());
    res.json(parsed);
  } catch (error) {
    console.error("Claim verification error:", error);
    res.status(500).json({ error: "Internal server error verifying claim." });
  }
});
async function setupViteMiddleware() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
}
setupViteMiddleware().then(() => {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`FindTrack Server booting successfully at http://0.0.0.0:${PORT}`);
  });
}).catch((err) => {
  console.error("Vite middleware hook failure:", err);
});
//# sourceMappingURL=server.cjs.map
